package com.cg.employeepayrollbackend.exceptions;

public class EmployeePayrollException extends RuntimeException {
    public EmployeePayrollException(String message) {
        super(message);
    }
}
