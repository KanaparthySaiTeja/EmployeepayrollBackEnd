package com.spring.messagingapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloMessagingAppApplicationTests {

    @Test
    void contextLoads() {
    }

}
