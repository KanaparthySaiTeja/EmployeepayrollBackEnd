export class Employee {
    id: any;
    name: any;
    salary: any;
    gender:any;
    startDate:any;
    note:any;
    profilePic:any;
    department:any; 
}